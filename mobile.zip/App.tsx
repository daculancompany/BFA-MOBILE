//@ts-nocheck
import React, { useState, useEffect } from "react";
import { StatusBar } from "expo-status-bar";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { Ionicons, FontAwesome } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";

import LoginScreen from "./screens/LoginScreen";
import RegisterScreen from "./screens/RegisterScreen";
import HomeScreen from "./screens/HomeScreen";
import ScheduleScreen from "./screens/ScheduleScreen";
import Profile from "./screens/Profile";
import BuildingInfoScreen from "./screens/BuildingInfoScreen";
import RegisterBuildingScreen from "./screens/RegisterBuildingScreen";
import InspectionForm from "./screens/InspectionForm";
import BuildingScreen from "./screens/MyBuilding";
import Booking from "./screens/Booking";

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

const DrawerNavigator = () => {
    const [userRole, setUserRole] = useState(null);

    useEffect(() => {
        const fetchUserRole = async () => {
            try {
                const role = await AsyncStorage.getItem("role");
                setUserRole(role);
            } catch (error) {
                console.error("Failed to fetch user role:", error);
            }
        };

        fetchUserRole();
    }, []);

    if (!userRole) return <></>;

    return (
        <Drawer.Navigator initialRouteName="Home">
            <Drawer.Screen
                name="Home"
                component={HomeScreen}
                options={{
                    drawerIcon: ({ color }) => (
                        <Ionicons name="home" size={24} color={color} />
                    ),
                    
                }}
            />
            <Drawer.Screen
                name="InspectionForm"
                component={InspectionForm}
                options={{
                    drawerItemStyle: { display: "none" }, // Hide from drawer
                    // headerLeft: () => (
                    //     <Ionicons
                    //       name="arrow-back"
                    //       size={24}
                    //       color="black"
                    //       onPress={() => navigation.goBack()} // Go back when the back button is pressed
                    //     />
                    //   ),
                }}
            />
            {userRole === "Building Owner" && (
                <>
                    <Drawer.Screen
                        name="Book A Survey"
                        component={ScheduleScreen}
                        options={{
                            drawerIcon: ({ color }) => (
                                <Ionicons
                                    name="calendar"
                                    size={24}
                                    color={color}
                                />
                            ),
                        }}
                    />

                    <Drawer.Screen
                        name="My Building"
                        component={BuildingScreen}
                        options={{
                            drawerIcon: ({ color }) => (
                                <FontAwesome
                                    name="building-o"
                                    size={24}
                                    color={color}
                                />
                            ),
                        }}
                    />
                    <Drawer.Screen
                        name="Register Building"
                        component={RegisterBuildingScreen}
                        options={{
                            drawerIcon: ({ color }) => (
                                <FontAwesome
                                    name="plus"
                                    size={24}
                                    color={color}
                                />
                            ),
                        }}
                    />
                    <Drawer.Screen
                        name="Booking list"
                        component={BuildingInfoScreen}
                        options={{
                            drawerIcon: ({ color }) => (
                                <Ionicons
                                    name="document-text-outline"
                                    size={24}
                                    color={color}
                                />
                            ),
                        }}
                    />
                </>
            )}
            {userRole !== "Building Owner" && (
                <>
                    <Drawer.Screen
                        name="Booking"
                        component={Booking}
                        options={{
                            drawerIcon: ({ color }) => (
                                <Ionicons
                                    name="document-text-outline"
                                    size={24}
                                    color={color}
                                />
                            ),
                        }}
                    />
                </>
            )}
            <Drawer.Screen
                name="Profile"
                component={Profile}
                options={{
                    drawerIcon: ({ color }) => (
                        <Ionicons name="person" size={24} color={color} />
                    ),
                }}
            />
        </Drawer.Navigator>
    );
};

export default function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Login">
                <Stack.Screen
                    options={{ headerShown: false }}
                    name="Login"
                    component={LoginScreen}
                />
                <Stack.Screen name="Register" component={RegisterScreen} />
                <Stack.Screen name="Main" options={{ headerShown: false }}>
                    {() => <DrawerNavigator />}
                </Stack.Screen>
            </Stack.Navigator>
            <StatusBar style="auto" />
        </NavigationContainer>
    );
}
